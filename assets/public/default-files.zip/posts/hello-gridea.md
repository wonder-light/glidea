
👏  欢迎使用 **Glidea** ！  
✍️  **Glidea** 一个静态博客写作客户端。你可以用它来记录你的生活、心情、知识、笔记、创意... ... 

<!-- more -->

[Github](https://github.com/wonder-light/glidea)  
[Glidea 主页](https://glidea.nianian.cn/)  
[示例网站](https://fehey.com/)

## 特性👇
📝  你可以使用简洁的 **Markdown** 语法，进行快速创作

🌉  你可以给文章配上精美的封面图和在文章任意位置插入图片

🏷️  你可以对文章进行标签分组

📋  你可以自定义菜单，可以创建外部链接菜单

💻  你可以在桌面端或移动端设备上使用此客户端

🌎  你可以使用 **𝖦𝗂𝗍𝗁𝗎𝖻 𝖯𝖺𝗀𝖾𝗌** 或 **Coding Pages** 向世界展示，未来将支持更多平台

<!--
💬  你可以进行简单的配置，接入 [Gitalk](https://github.com/gitalk/gitalk) 或 [DisqusJS](https://github.com/SukkaW/DisqusJS) 评论系统
-->

🗺️  你可以使用**中文简体**、**英语**等等

🌁  你可以任意使用默认主题或任意第三方主题，有强大的主题自定义能力

🖥  你可以自定义源文件夹，利用 OneDrive、百度网盘等进行多设备同步

🌱 当然 **Glidea** 或许现在还有些许不完美，但请相信，**Glidea** 会不断打磨自己，努力成为你的得力伙伴

💪 让我们一起携手前行，迎接更加美好的未来！

😘 Enjoy the journey with Glidea!